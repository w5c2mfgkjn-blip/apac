# NEXUS CYBER STUDIO

**Advanced platform for cybersecurity analysis, web inspection, script development, code protection, and official Roblox management.**

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Node](https://img.shields.io/badge/node-%3E%3D18-green)
![License](https://img.shields.io/badge/license-MIT-lightgrey)

---

## Features

| Module | Description |
|--------|-------------|
| **URL Inspector** | Analyze public web pages: HTML, headers, scripts, CSS, links, redirects. SSRF-protected. |
| **Source Map Explorer** | Load and explore public `.map` files to view original source. |
| **Script Lab** | Multi-language code editor (JS, HTML, CSS, Lua, Luau, JSON, Python) with format, analyze, tabs. |
| **Script Protector** | Obfuscate, minify and compact JavaScript. Includes security warnings. |
| **Script Analyzer** | Detect functions, variables, dependencies and potential issues. |
| **Luau Studio** | Specialized editor for Roblox scripts with templates and remote analysis. |
| **Roblox Control Center** | Official Open Cloud API integration for **your own** experiences. |
| **Security Center** | Scan code for hardcoded secrets, dangerous patterns and suspicious URLs. |
| **File Manager & Projects** | Create and manage independent projects. |
| **Terminal** | Safe command interface for project operations. |

---

## Requirements

- **Node.js** >= 18.0.0
- npm or yarn

---

## Installation

### Opción 1 — Servidor completo (recomendado)

```bash
cd NEXUS-CYBER-STUDIO
npm install
cp .env.example .env
npm start
```

Abre **http://localhost:3000**

### Opción 2 — GitHub Pages (solo interfaz)

El archivo `index.html` está en la **raíz** del proyecto para que GitHub no dé 404.

1. Sube el repo a GitHub
2. Settings → Pages → Source: branch `main` → folder `/ (root)`
3. Guarda

Nota: las herramientas que necesitan backend (Inspector, Protector, Roblox API, etc.) solo funcionan con la Opción 1.

---

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `PORT` | Server port (default: 3000) | No |
| `ROBLOX_API_KEY` | Roblox Open Cloud API Key | Only for Roblox features |
| `ROBLOX_UNIVERSE_ID` | Default Universe ID | No |
| `MAX_HTML_SIZE` | Max HTML fetch size in bytes | No |
| `RATE_LIMIT_MAX_REQUESTS` | Rate limit per window | No |

### Roblox API Key Setup

1. Go to [create.roblox.com/credentials](https://create.roblox.com/credentials)
2. Create an API Key with permissions for the Universes you own
3. Paste it into `.env` as `ROBLOX_API_KEY=...`
4. Restart the server

**The API key never leaves the backend.** It is never sent to the browser.

---

## Security Notes

- **SSRF Protection**: Private IPs, localhost and internal metadata endpoints are blocked.
- **No secret exposure**: API keys and secrets stay in `.env` / backend only.
- **Obfuscation warning**: Client-side obfuscation is not real security. Move sensitive logic to the server.
- **Rate limiting**: Applied to all `/api/` routes.
- **Input validation**: URLs and project names are validated.

---

## Project Structure

```
NEXUS-CYBER-STUDIO/
├── package.json
├── server.js                 # Express server
├── .env.example
├── README.md
├── public/                   # Frontend
│   ├── index.html
│   ├── css/
│   └── js/
├── backend/
│   ├── routes/               # API routes
│   ├── services/             # Business logic
│   └── middleware/           # Security & auth
└── workspace/
    └── projects/             # User projects (created at runtime)
```

---

## Usage Tips

- **Mobile / iPhone**: Fully responsive. Use the ☰ button to open the sidebar.
- **Script Lab**: Supports multiple tabs. Use Format for JS/HTML/CSS.
- **Inspector**: Only public HTTP/HTTPS URLs. Private networks are blocked.
- **Roblox**: You must own the Universe and grant the API key the correct permissions.

---

## License

MIT

---

**NEXUS CYBER STUDIO** — Built for developers who take security and tooling seriously.

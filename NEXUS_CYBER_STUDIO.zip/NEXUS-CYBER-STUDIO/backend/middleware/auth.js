/**
 * Auth Middleware
 * Simple protection for sensitive routes
 * In production, implement proper JWT or session auth
 */

function requireApiKey(req, res, next) {
  // For Roblox routes that need API key configured
  if (!process.env.ROBLOX_API_KEY || process.env.ROBLOX_API_KEY === 'your_roblox_open_cloud_api_key_here') {
    return res.status(503).json({
      success: false,
      error: 'Roblox API Key not configured. Set ROBLOX_API_KEY in .env file.',
      help: 'Get your key from https://create.roblox.com/credentials'
    });
  }
  next();
}

module.exports = {
  requireApiKey
};

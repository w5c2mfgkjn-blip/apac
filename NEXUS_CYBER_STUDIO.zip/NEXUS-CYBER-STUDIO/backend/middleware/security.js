/**
 * Security Middleware
 * SSRF protection, input validation, private IP blocking
 */

const validator = require('validator');
const { URL } = require('url');

// Private IP ranges and localhost
const PRIVATE_IP_PATTERNS = [
  /^127\./,
  /^10\./,
  /^192\.168\./,
  /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
  /^169\.254\./,
  /^0\./,
  /^::1$/,
  /^fc00:/i,
  /^fe80:/i,
  /^localhost$/i,
  /^\[::1\]$/
];

function isPrivateHost(hostname) {
  if (!hostname) return true;
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  return PRIVATE_IP_PATTERNS.some(pattern => pattern.test(host));
}

function validatePublicUrl(urlString) {
  if (!urlString || typeof urlString !== 'string') {
    return { valid: false, error: 'URL is required' };
  }

  let url;
  try {
    // Ensure protocol
    if (!/^https?:\/\//i.test(urlString)) {
      urlString = 'https://' + urlString;
    }
    url = new URL(urlString);
  } catch (e) {
    return { valid: false, error: 'Invalid URL format' };
  }

  if (!['http:', 'https:'].includes(url.protocol)) {
    return { valid: false, error: 'Only HTTP and HTTPS protocols are allowed' };
  }

  if (isPrivateHost(url.hostname)) {
    return { valid: false, error: 'Access to private/local addresses is blocked (SSRF protection)' };
  }

  // Block common internal service names
  const blockedHosts = ['metadata', 'metadata.google', '169.254.169.254', 'instance-data'];
  if (blockedHosts.some(b => url.hostname.includes(b))) {
    return { valid: false, error: 'Access to this host is blocked' };
  }

  return { valid: true, url: url.toString() };
}

function sanitizeFilename(name) {
  return name.replace(/[^a-zA-Z0-9._\-]/g, '_').substring(0, 100);
}

module.exports = {
  isPrivateHost,
  validatePublicUrl,
  sanitizeFilename
};

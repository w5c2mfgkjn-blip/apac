/**
 * URL Inspector Routes
 */

const express = require('express');
const router = express.Router();
const { analyzePage, fetchResourceContent } = require('../services/web-inspector');
const { validatePublicUrl } = require('../middleware/security');

router.post('/analyze', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'URL is required' });
    }

    const validation = validatePublicUrl(url);
    if (!validation.valid) {
      return res.status(400).json({ success: false, error: validation.error });
    }

    const result = await analyzePage(validation.url);
    res.json(result);
  } catch (err) {
    console.error('[Inspector]', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/fetch', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'URL is required' });
    }

    const validation = validatePublicUrl(url);
    if (!validation.valid) {
      return res.status(400).json({ success: false, error: validation.error });
    }

    const result = await fetchResourceContent(validation.url);
    res.json(result);
  } catch (err) {
    console.error('[Inspector Fetch]', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/headers', async (req, res) => {
  try {
    const { url } = req.body;
    const validation = validatePublicUrl(url);
    if (!validation.valid) {
      return res.status(400).json({ success: false, error: validation.error });
    }

    const axios = require('axios');
    const response = await axios.head(validation.url, {
      timeout: 10000,
      maxRedirects: 5,
      validateStatus: () => true
    });

    res.json({
      success: true,
      url: validation.url,
      status: response.status,
      headers: response.headers
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;

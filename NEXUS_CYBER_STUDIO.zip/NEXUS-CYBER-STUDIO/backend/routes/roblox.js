/**
 * Roblox Open Cloud Routes
 * Official API only - for your own experiences
 */

const express = require('express');
const router = express.Router();
const { requireApiKey } = require('../middleware/auth');
const roblox = require('../services/roblox-api');

router.get('/status', async (req, res) => {
  try {
    const status = await roblox.testConnection();
    res.json(status);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/universe/:id', requireApiKey, async (req, res) => {
  try {
    const data = await roblox.getUniverse(req.params.id);
    res.json({ success: true, data });
  } catch (err) {
    const status = err.response?.status || 500;
    res.status(status).json({
      success: false,
      error: err.response?.data?.message || err.message,
      note: 'Ensure the API key has permission for this Universe ID and that you own it.'
    });
  }
});

router.get('/universe/:id/places', requireApiKey, async (req, res) => {
  try {
    const data = await roblox.getPlaceDetails(req.params.id);
    res.json({ success: true, data });
  } catch (err) {
    res.status(err.response?.status || 500).json({
      success: false,
      error: err.response?.data?.message || err.message
    });
  }
});

router.get('/universe/:id/datastores', requireApiKey, async (req, res) => {
  try {
    const data = await roblox.getDataStoreList(req.params.id);
    res.json({ success: true, data });
  } catch (err) {
    res.status(err.response?.status || 500).json({
      success: false,
      error: err.response?.data?.message || err.message
    });
  }
});

router.get('/help', (req, res) => {
  res.json({
    success: true,
    message: 'Roblox Open Cloud Integration',
    setup: [
      '1. Go to https://create.roblox.com/credentials',
      '2. Create an API Key with the necessary permissions (Universe, DataStores, etc.)',
      '3. Add the key to your .env file as ROBLOX_API_KEY',
      '4. Optionally set ROBLOX_UNIVERSE_ID for default universe',
      '5. Restart the server'
    ],
    docs: 'https://create.roblox.com/docs/cloud/open-cloud',
    security: 'API Key is stored only in the backend environment. It is never sent to the browser.'
  });
});

module.exports = router;

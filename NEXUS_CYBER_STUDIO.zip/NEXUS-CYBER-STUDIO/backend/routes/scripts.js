/**
 * Scripts Routes - Format, Obfuscate, Analyze, Source Maps
 */

const express = require('express');
const router = express.Router();
const { formatCode, analyzeJavaScript, detectLanguage } = require('../services/script-formatter');
const { obfuscateCode, minifyCode, compactCode } = require('../services/script-obfuscator');
const { validatePublicUrl } = require('../middleware/security');
const axios = require('axios');
const sourceMap = require('source-map');

router.post('/format', async (req, res) => {
  try {
    const { code, language } = req.body;
    if (!code) return res.status(400).json({ success: false, error: 'Code is required' });
    
    const result = formatCode(code, language || detectLanguage(code));
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/obfuscate', async (req, res) => {
  try {
    const { code, options } = req.body;
    if (!code) return res.status(400).json({ success: false, error: 'Code is required' });
    
    const result = await obfuscateCode(code, options || {});
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/minify', async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) return res.status(400).json({ success: false, error: 'Code is required' });
    
    const result = await minifyCode(code);
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/compact', async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) return res.status(400).json({ success: false, error: 'Code is required' });
    
    const result = compactCode(code);
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/analyze', async (req, res) => {
  try {
    const { code, language } = req.body;
    if (!code) return res.status(400).json({ success: false, error: 'Code is required' });
    
    const lang = language || detectLanguage(code);
    let analysis;
    
    if (lang === 'javascript' || lang === 'js') {
      analysis = analyzeJavaScript(code);
    } else {
      // Basic analysis for other languages
      analysis = {
        functions: [],
        variables: [],
        potentialIssues: [],
        summary: `Basic analysis for ${lang}. Full AST analysis available for JavaScript.`
      };
      
      // Simple Lua function detection
      if (lang === 'lua' || lang === 'luau') {
        const funcMatches = code.match(/function\s+([\w.:]+)/g) || [];
        analysis.functions = funcMatches.map(f => f.replace('function ', ''));
        analysis.summary = `Found ${analysis.functions.length} functions in Lua/Luau code.`;
      }
    }
    
    res.json({ success: true, language: lang, analysis });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/source-map', async (req, res) => {
  try {
    const { url, content } = req.body;
    
    let mapContent = content;
    
    if (url && !content) {
      const validation = validatePublicUrl(url);
      if (!validation.valid) {
        return res.status(400).json({ success: false, error: validation.error });
      }
      
      const response = await axios.get(validation.url, {
        timeout: 10000,
        maxContentLength: 5 * 1024 * 1024
      });
      mapContent = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
    }
    
    if (!mapContent) {
      return res.status(400).json({ success: false, error: 'Source map URL or content required' });
    }
    
    let mapData;
    try {
      mapData = typeof mapContent === 'string' ? JSON.parse(mapContent) : mapContent;
    } catch (e) {
      return res.status(400).json({ success: false, error: 'Invalid source map JSON' });
    }
    
    const consumer = await new sourceMap.SourceMapConsumer(mapData);
    
    const sources = consumer.sources || [];
    const sourcesContent = consumer.sourcesContent || [];
    
    const files = sources.map((source, i) => ({
      name: source,
      content: sourcesContent[i] || null,
      hasContent: !!sourcesContent[i]
    }));
    
    consumer.destroy();
    
    res.json({
      success: true,
      version: mapData.version,
      file: mapData.file,
      sourceRoot: mapData.sourceRoot,
      sourcesCount: sources.length,
      files,
      note: 'Only publicly available source maps can be analyzed. Private maps are not accessible.'
    });
  } catch (err) {
    console.error('[SourceMap]', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;

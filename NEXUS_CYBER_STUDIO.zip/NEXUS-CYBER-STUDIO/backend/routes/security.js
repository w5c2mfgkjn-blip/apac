/**
 * Security Center Routes
 */

const express = require('express');
const router = express.Router();
const { analyzeJavaScript } = require('../services/script-formatter');

router.post('/scan', async (req, res) => {
  try {
    const { code, language } = req.body;
    if (!code) {
      return res.status(400).json({ success: false, error: 'Code is required' });
    }

    const analysis = analyzeJavaScript(code);
    
    // Additional security checks
    const warnings = [...analysis.potentialIssues];
    
    // Credential patterns
    const credentialPatterns = [
      { regex: /(?:api[_-]?key|apikey)\s*[:=]\s*['"][^'"]{8,}['"]/gi, msg: 'Hardcoded API key pattern detected' },
      { regex: /(?:password|passwd|pwd)\s*[:=]\s*['"][^'"]+['"]/gi, msg: 'Hardcoded password pattern detected' },
      { regex: /(?:secret|token|auth)\s*[:=]\s*['"][^'"]{10,}['"]/gi, msg: 'Possible hardcoded secret/token' },
      { regex: /Bearer\s+[A-Za-z0-9\-._~+/]+=*/g, msg: 'Bearer token pattern found' },
      { regex: /https?:\/\/[^\s'"]+@[^\s'"]+/g, msg: 'URL with embedded credentials detected' }
    ];

    credentialPatterns.forEach(({ regex, msg }) => {
      if (regex.test(code)) {
        warnings.push(msg);
      }
    });

    // Suspicious URLs
    const urlMatches = code.match(/https?:\/\/[^\s'"`]+/g) || [];
    const suspiciousUrls = urlMatches.filter(u => 
      /pastebin|discord\.com\/api\/webhooks|ngrok|raw\.githubusercontent/i.test(u)
    );

    if (suspiciousUrls.length > 0) {
      warnings.push(`Suspicious external URLs found: ${suspiciousUrls.slice(0, 3).join(', ')}`);
    }

    res.json({
      success: true,
      score: Math.max(0, 100 - (warnings.length * 12)),
      warnings,
      functions: analysis.functions,
      dependencies: analysis.dependencies,
      summary: analysis.summary,
      recommendations: [
        'Never hardcode secrets in client-side code',
        'Move sensitive logic to server-side',
        'Validate all user inputs',
        'Use environment variables for configuration',
        'Keep dependencies updated'
      ]
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/check-url', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ success: false, error: 'URL required' });

    const issues = [];
    if (/^http:\/\//i.test(url)) {
      issues.push('Insecure HTTP protocol (prefer HTTPS)');
    }
    if (/[?&](password|token|key|secret)=/i.test(url)) {
      issues.push('Possible sensitive data in URL query parameters');
    }
    if (/\.(exe|bat|cmd|sh|ps1)(\?|$)/i.test(url)) {
      issues.push('URL points to potentially executable file');
    }

    res.json({
      success: true,
      url,
      issues,
      safe: issues.length === 0
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;

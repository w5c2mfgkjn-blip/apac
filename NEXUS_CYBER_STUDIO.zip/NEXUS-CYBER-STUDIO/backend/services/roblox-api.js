/**
 * Roblox Open Cloud API Service
 * Official API only - for YOUR experiences
 * API Key stays in backend (.env)
 */

const axios = require('axios');

const ROBLOX_BASE = 'https://apis.roblox.com';

function getClient() {
  const apiKey = process.env.ROBLOX_API_KEY;
  if (!apiKey || apiKey === 'your_roblox_open_cloud_api_key_here') {
    throw new Error('ROBLOX_API_KEY not configured in environment');
  }

  return axios.create({
    baseURL: ROBLOX_BASE,
    timeout: 15000,
    headers: {
      'x-api-key': apiKey,
      'Content-Type': 'application/json'
    }
  });
}

async function getUniverse(universeId) {
  const client = getClient();
  const id = universeId || process.env.ROBLOX_UNIVERSE_ID;
  if (!id) throw new Error('Universe ID required');

  const res = await client.get(`/universes/v1/${id}`);
  return res.data;
}

async function listUniverses() {
  // Open Cloud does not have a simple "list all my universes" for all keys.
  // User must provide Universe IDs they own.
  return {
    message: 'Provide specific Universe IDs you own. Open Cloud requires the Universe ID for most operations.',
    docs: 'https://create.roblox.com/docs/cloud/open-cloud'
  };
}

async function getPlaceDetails(universeId, placeId) {
  const client = getClient();
  // Places are under universe
  const res = await client.get(`/universes/v1/${universeId}/places`);
  return res.data;
}

async function getDataStoreList(universeId) {
  const client = getClient();
  const res = await client.get(`/datastores/v1/universes/${universeId}/standard-datastores`);
  return res.data;
}

async function getServerList(universeId) {
  // Note: Live servers listing has limited support depending on API version
  // This is a placeholder for compatible endpoints
  try {
    const client = getClient();
    // Actual endpoint may vary; check current Open Cloud docs
    return {
      note: 'Server listing depends on current Open Cloud capabilities and permissions of your API key.',
      docs: 'https://create.roblox.com/docs/cloud/open-cloud'
    };
  } catch (err) {
    throw err;
  }
}

async function testConnection() {
  try {
    const client = getClient();
    // Simple call to verify key works - using a known public endpoint structure
    // Actual validation happens on first real call
    return {
      success: true,
      message: 'API Key is configured. Make a specific request with a Universe ID you own to verify permissions.',
      hasKey: true
    };
  } catch (err) {
    return {
      success: false,
      message: err.message,
      hasKey: false
    };
  }
}

module.exports = {
  getUniverse,
  listUniverses,
  getPlaceDetails,
  getDataStoreList,
  getServerList,
  testConnection
};

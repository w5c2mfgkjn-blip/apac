/**
 * Script Formatter & Analyzer Service
 */

const beautify = require('js-beautify');
const acorn = require('acorn');

function formatCode(code, language = 'javascript') {
  try {
    let formatted;
    switch (language.toLowerCase()) {
      case 'javascript':
      case 'js':
      case 'json':
        formatted = beautify.js(code, {
          indent_size: 2,
          space_in_empty_paren: true,
          preserve_newlines: true,
          max_preserve_newlines: 2
        });
        break;
      case 'html':
        formatted = beautify.html(code, {
          indent_size: 2,
          wrap_line_length: 120
        });
        break;
      case 'css':
        formatted = beautify.css(code, {
          indent_size: 2
        });
        break;
      default:
        // For Lua, Python etc. just return with basic cleanup
        formatted = code.trim();
    }
    return { success: true, code: formatted };
  } catch (err) {
    return { success: false, error: err.message, code };
  }
}

function analyzeJavaScript(code) {
  const analysis = {
    functions: [],
    variables: [],
    calls: [],
    potentialIssues: [],
    dependencies: [],
    summary: ''
  };

  try {
    // Basic regex-based analysis (safe, no eval)
    // Functions
    const funcRegex = /(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:function|\([^)]*\)\s*=>))/g;
    let match;
    while ((match = funcRegex.exec(code)) !== null) {
      const name = match[1] || match[2];
      if (name && !analysis.functions.includes(name)) {
        analysis.functions.push(name);
      }
    }

    // Arrow functions assigned
    const arrowRegex = /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/g;
    while ((match = arrowRegex.exec(code)) !== null) {
      if (!analysis.functions.includes(match[1])) {
        analysis.functions.push(match[1]);
      }
    }

    // Variables
    const varRegex = /(?:const|let|var)\s+(\w+)/g;
    while ((match = varRegex.exec(code)) !== null) {
      if (!analysis.variables.includes(match[1]) && !analysis.functions.includes(match[1])) {
        analysis.variables.push(match[1]);
      }
    }

    // External calls / dangerous patterns
    const dangerous = [
      { pattern: /eval\s*\(/g, issue: 'Use of eval() - potential code injection risk' },
      { pattern: /Function\s*\(/g, issue: 'Use of Function constructor - potential code injection' },
      { pattern: /document\.write\s*\(/g, issue: 'document.write() can be dangerous' },
      { pattern: /innerHTML\s*=/g, issue: 'innerHTML assignment - possible XSS vector' },
      { pattern: /localStorage\.|sessionStorage\./g, issue: 'Browser storage usage detected' },
      { pattern: /fetch\s*\(|XMLHttpRequest|axios\./g, issue: 'External HTTP calls detected' },
      { pattern: /password|api[_-]?key|secret|token/gi, issue: 'Possible credential/sensitive data reference' },
      { pattern: /require\s*\(\s*['"]child_process['"]|exec\s*\(|spawn\s*\(/g, issue: 'Possible command execution' }
    ];

    dangerous.forEach(({ pattern, issue }) => {
      if (pattern.test(code)) {
        analysis.potentialIssues.push(issue);
      }
    });

    // Try to detect imports/requires
    const importRegex = /(?:import\s+.*?from\s+['"]([^'"]+)['"]|require\s*\(\s*['"]([^'"]+)['"]\s*\))/g;
    while ((match = importRegex.exec(code)) !== null) {
      const dep = match[1] || match[2];
      if (dep && !analysis.dependencies.includes(dep)) {
        analysis.dependencies.push(dep);
      }
    }

    // Simple AST attempt for better function detection
    try {
      const ast = acorn.parse(code, { ecmaVersion: 2022, sourceType: 'module', locations: true });
      // Walk basic nodes if needed - keep simple
    } catch (e) {
      // Ignore parse errors for incomplete code
    }

    analysis.summary = `Found ${analysis.functions.length} functions, ${analysis.variables.length} variables, ${analysis.dependencies.length} dependencies. ${analysis.potentialIssues.length} potential issues detected.`;
    
  } catch (err) {
    analysis.summary = 'Analysis partially failed: ' + err.message;
  }

  return analysis;
}

function detectLanguage(code) {
  if (/^\s*<(!DOCTYPE|html|head|body)/i.test(code)) return 'html';
  if (/^\s*[{[]/.test(code.trim()) || /"\w+":\s*/.test(code)) return 'json';
  if (/function\s+\w+|const\s+\w+\s*=|let\s+\w+|var\s+\w+|=>\s*{/.test(code)) return 'javascript';
  if (/^\s*(local\s+)?function\s+\w+|game:GetService|RemoteEvent|Instance\.new/.test(code)) return 'lua';
  if (/def\s+\w+|import\s+\w+|print\s*\(/.test(code)) return 'python';
  if (/{\s*[\w-]+\s*:/.test(code) || /\.\w+\s*{/.test(code)) return 'css';
  return 'javascript';
}

module.exports = {
  formatCode,
  analyzeJavaScript,
  detectLanguage
};

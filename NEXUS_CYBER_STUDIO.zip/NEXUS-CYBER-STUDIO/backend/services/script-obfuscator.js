/**
 * Script Obfuscator & Minifier Service
 * Uses javascript-obfuscator and terser
 */

const JavaScriptObfuscator = require('javascript-obfuscator');
const { minify } = require('terser');

async function obfuscateCode(code, options = {}) {
  try {
    const defaultOptions = {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 0.5,
      deadCodeInjection: false,
      debugProtection: false,
      disableConsoleOutput: false,
      identifierNamesGenerator: 'hexadecimal',
      log: false,
      numbersToExpressions: true,
      renameGlobals: false,
      selfDefending: false,
      simplify: true,
      splitStrings: true,
      splitStringsChunkLength: 5,
      stringArray: true,
      stringArrayEncoding: ['base64'],
      stringArrayThreshold: 0.75,
      transformObjectKeys: true,
      unicodeEscapeSequence: false
    };

    const result = JavaScriptObfuscator.obfuscate(code, { ...defaultOptions, ...options });
    
    return {
      success: true,
      code: result.getObfuscatedCode(),
      originalSize: Buffer.byteLength(code),
      obfuscatedSize: Buffer.byteLength(result.getObfuscatedCode()),
      warning: 'Obfuscation makes code harder to read but does NOT make it impossible to reverse-engineer. Never rely on client-side obfuscation to protect secrets or critical logic. Move sensitive operations to a server.'
    };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

async function minifyCode(code) {
  try {
    const result = await minify(code, {
      compress: {
        dead_code: true,
        drop_console: false,
        passes: 2
      },
      mangle: true,
      format: {
        comments: false
      }
    });

    if (result.error) {
      return { success: false, error: result.error.message };
    }

    return {
      success: true,
      code: result.code,
      originalSize: Buffer.byteLength(code),
      minifiedSize: Buffer.byteLength(result.code)
    };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

function compactCode(code) {
  // Simple compact: remove comments and excess whitespace
  let result = code
    .replace(/\/\*[\s\S]*?\*\//g, '') // block comments
    .replace(/\/\/.*$/gm, '') // line comments
    .replace(/\s+/g, ' ')
    .replace(/\s*([{};,:])\s*/g, '$1')
    .trim();
  
  return {
    success: true,
    code: result,
    originalSize: Buffer.byteLength(code),
    compactedSize: Buffer.byteLength(result)
  };
}

module.exports = {
  obfuscateCode,
  minifyCode,
  compactCode
};

/**
 * Web Inspector Service
 * Analyzes public web pages safely
 */

const axios = require('axios');
const cheerio = require('cheerio');
const { URL } = require('url');
const { validatePublicUrl } = require('../middleware/security');

const MAX_SIZE = parseInt(process.env.MAX_HTML_SIZE) || 2 * 1024 * 1024; // 2MB
const TIMEOUT = 15000;

const axiosInstance = axios.create({
  timeout: TIMEOUT,
  maxRedirects: 5,
  maxContentLength: MAX_SIZE,
  maxBodyLength: MAX_SIZE,
  validateStatus: (status) => status < 500,
  headers: {
    'User-Agent': 'NexusCyberStudio/1.0 (Public Web Analyzer; +https://github.com/nexus-cyber-studio)',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9'
  }
});

async function fetchResource(url, options = {}) {
  const validation = validatePublicUrl(url);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  try {
    const response = await axiosInstance.get(validation.url, {
      responseType: options.binary ? 'arraybuffer' : 'text',
      headers: options.headers || {}
    });

    return {
      url: response.request?.res?.responseUrl || validation.url,
      status: response.status,
      statusText: response.statusText,
      headers: response.headers,
      data: response.data,
      size: response.headers['content-length'] 
        ? parseInt(response.headers['content-length']) 
        : (typeof response.data === 'string' ? Buffer.byteLength(response.data) : response.data?.byteLength || 0)
    };
  } catch (err) {
    if (err.code === 'ECONNABORTED') {
      throw new Error('Request timed out');
    }
    if (err.response) {
      throw new Error(`HTTP ${err.response.status}: ${err.response.statusText}`);
    }
    throw new Error(err.message || 'Failed to fetch resource');
  }
}

async function analyzePage(url) {
  const result = await fetchResource(url);
  const $ = cheerio.load(result.data);
  const baseUrl = new URL(result.url);

  // Extract resources
  const scripts = [];
  const styles = [];
  const links = [];
  const images = [];
  const sourceMaps = [];

  // Scripts
  $('script[src]').each((_, el) => {
    const src = $(el).attr('src');
    if (src) {
      try {
        const absolute = new URL(src, baseUrl).toString();
        scripts.push({
          src: absolute,
          type: $(el).attr('type') || 'text/javascript',
          async: $(el).attr('async') !== undefined,
          defer: $(el).attr('defer') !== undefined
        });
        if (src.includes('.map') || $(el).attr('src')?.endsWith('.js')) {
          // Potential source map reference
        }
      } catch (e) {}
    }
  });

  // Inline scripts count
  const inlineScripts = $('script:not([src])').length;

  // Stylesheets
  $('link[rel="stylesheet"]').each((_, el) => {
    const href = $(el).attr('href');
    if (href) {
      try {
        styles.push({
          href: new URL(href, baseUrl).toString(),
          media: $(el).attr('media') || 'all'
        });
      } catch (e) {}
    }
  });

  // Other links
  $('a[href]').each((_, el) => {
    const href = $(el).attr('href');
    if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
      try {
        const absolute = new URL(href, baseUrl).toString();
        if (!links.find(l => l.href === absolute)) {
          links.push({
            href: absolute,
            text: $(el).text().trim().substring(0, 100),
            rel: $(el).attr('rel') || ''
          });
        }
      } catch (e) {}
    }
  });

  // Images
  $('img[src]').each((_, el) => {
    const src = $(el).attr('src');
    if (src) {
      try {
        images.push({
          src: new URL(src, baseUrl).toString(),
          alt: $(el).attr('alt') || '',
          width: $(el).attr('width'),
          height: $(el).attr('height')
        });
      } catch (e) {}
    }
  });

  // Look for sourceMappingURL comments
  const sourceMapMatches = result.data.match(/\/\/[#@]\s*sourceMappingURL\s*=\s*(\S+)/g) || [];
  sourceMapMatches.forEach(match => {
    const mapUrl = match.split('=')[1]?.trim();
    if (mapUrl) {
      try {
        sourceMaps.push(new URL(mapUrl, baseUrl).toString());
      } catch (e) {}
    }
  });

  // Meta info
  const title = $('title').text().trim();
  const description = $('meta[name="description"]').attr('content') || '';
  const generator = $('meta[name="generator"]').attr('content') || '';

  return {
    success: true,
    url: result.url,
    status: result.status,
    statusText: result.statusText,
    headers: result.headers,
    contentType: result.headers['content-type'] || 'unknown',
    size: result.size,
    sizeFormatted: formatBytes(result.size),
    title,
    description,
    generator,
    resources: {
      scripts: {
        external: scripts,
        inlineCount: inlineScripts,
        total: scripts.length + inlineScripts
      },
      stylesheets: styles,
      links: links.slice(0, 100), // Limit
      images: images.slice(0, 50),
      sourceMaps
    },
    html: result.data.substring(0, 500000), // Limit HTML returned
    htmlLength: result.data.length
  };
}

async function fetchResourceContent(url) {
  const result = await fetchResource(url);
  return {
    success: true,
    url: result.url,
    status: result.status,
    headers: result.headers,
    contentType: result.headers['content-type'] || 'unknown',
    size: result.size,
    sizeFormatted: formatBytes(result.size),
    content: typeof result.data === 'string' ? result.data : result.data.toString('utf8')
  };
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

module.exports = {
  analyzePage,
  fetchResourceContent,
  fetchResource
};

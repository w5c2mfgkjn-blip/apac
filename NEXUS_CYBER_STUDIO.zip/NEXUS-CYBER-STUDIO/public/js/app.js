/**
 * NEXUS CYBER STUDIO - Core Application
 */

const NexusApp = {
  version: '1.0.0',
  
  init() {
    this.checkHealth();
    this.setupGlobalHandlers();
    this.log('System initialized');
  },
  
  async checkHealth() {
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      const el = document.getElementById('status-backend');
      if (el) {
        el.textContent = data.status === 'ok' ? 'Online' : 'Error';
        el.style.color = data.status === 'ok' ? 'var(--accent-green)' : 'var(--accent-red)';
      }
      document.getElementById('connection-status').textContent = 'Online';
    } catch (e) {
      const el = document.getElementById('status-backend');
      if (el) {
        el.textContent = 'Offline';
        el.style.color = 'var(--accent-red)';
      }
      document.getElementById('connection-status').textContent = 'Offline';
    }
    
    // Check Roblox
    try {
      const res = await fetch('/api/roblox/status');
      const data = await res.json();
      const el = document.getElementById('status-roblox');
      if (el) {
        el.textContent = data.hasKey ? 'Configured' : 'Not configured';
        el.style.color = data.hasKey ? 'var(--accent-green)' : 'var(--text-muted)';
      }
    } catch (e) {
      const el = document.getElementById('status-roblox');
      if (el) el.textContent = '—';
    }
  },
  
  setupGlobalHandlers() {
    // Activity indicator helpers
    window.showActivity = () => {
      document.getElementById('activity-indicator')?.classList.remove('hidden');
    };
    window.hideActivity = () => {
      document.getElementById('activity-indicator')?.classList.add('hidden');
    };
    
    // Notification system
    window.notify = (message, type = 'info', duration = 4000) => {
      const container = document.getElementById('notifications');
      const el = document.createElement('div');
      el.className = `notification ${type}`;
      el.innerHTML = `<span>${message}</span>`;
      container.appendChild(el);
      setTimeout(() => {
        el.style.opacity = '0';
        el.style.transform = 'translateX(100%)';
        setTimeout(() => el.remove(), 300);
      }, duration);
    };
    
    // Modal helpers
    window.showModal = (title, bodyHtml, footerHtml = '') => {
      document.getElementById('modal-title').textContent = title;
      document.getElementById('modal-body').innerHTML = bodyHtml;
      document.getElementById('modal-footer').innerHTML = footerHtml;
      document.getElementById('modal').classList.remove('hidden');
    };
    
    window.hideModal = () => {
      document.getElementById('modal').classList.add('hidden');
    };
    
    document.getElementById('modal-close')?.addEventListener('click', hideModal);
    document.getElementById('modal')?.addEventListener('click', (e) => {
      if (e.target.id === 'modal') hideModal();
    });
    
    // Quick goto buttons
    document.querySelectorAll('[data-goto]').forEach(btn => {
      btn.addEventListener('click', () => {
        const section = btn.dataset.goto;
        if (window.navigateTo) window.navigateTo(section);
      });
    });
  },
  
  log(msg) {
    const log = document.getElementById('activity-log');
    if (log) {
      const entry = document.createElement('div');
      entry.className = 'log-entry';
      const time = new Date().toLocaleTimeString();
      entry.textContent = `[${time}] ${msg}`;
      log.insertBefore(entry, log.firstChild);
      // Keep last 20
      while (log.children.length > 20) log.removeChild(log.lastChild);
    }
  },
  
  // Utility: download text as file
  downloadFile(content, filename, mime = 'text/plain') {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  },
  
  // Utility: copy to clipboard
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      notify('Copied to clipboard', 'success');
      return true;
    } catch (e) {
      notify('Failed to copy', 'error');
      return false;
    }
  },
  
  // API helper
  async api(endpoint, options = {}) {
    showActivity();
    try {
      const res = await fetch(endpoint, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers
        },
        ...options
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || `HTTP ${res.status}`);
      }
      return data;
    } finally {
      hideActivity();
    }
  }
};

// Init on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  NexusApp.init();
});

/**
 * File Manager & Projects Module
 */

document.addEventListener('DOMContentLoaded', () => {
  loadProjects();
  
  document.getElementById('projects-create')?.addEventListener('click', createProject);
  document.getElementById('files-refresh')?.addEventListener('click', () => {
    const sel = document.getElementById('files-project');
    if (sel.value) loadProjectFiles(sel.value);
  });
  document.getElementById('files-project')?.addEventListener('change', (e) => {
    if (e.target.value) loadProjectFiles(e.target.value);
  });
  document.getElementById('files-new-folder')?.addEventListener('click', () => notify('Folder creation: use Projects section to manage structure', 'info'));
  document.getElementById('files-new-file')?.addEventListener('click', () => notify('Create files via Script Lab and save to a project', 'info'));
  
  window.addEventListener('section-change', (e) => {
    if (e.detail === 'projects' || e.detail === 'files') loadProjects();
  });
});

async function loadProjects() {
  try {
    const data = await NexusApp.api('/api/projects');
    const list = document.getElementById('projects-list');
    const select = document.getElementById('files-project');
    
    if (!data.projects || data.projects.length === 0) {
      if (list) list.innerHTML = '<div class="empty-state">No projects yet. Create one!</div>';
      if (select) select.innerHTML = '<option value="">No projects</option>';
      return;
    }
    
    if (list) {
      list.innerHTML = data.projects.map(p => `
        <div class="project-card" data-name="${escape(p.name)}">
          <h4>${escape(p.name)}</h4>
          <p>${escape(p.description || 'No description')}</p>
          <div class="meta">
            Created: ${new Date(p.created).toLocaleDateString()}
            ${p.modified ? ' • Modified: ' + new Date(p.modified).toLocaleDateString() : ''}
          </div>
          <div class="btn-row" style="margin-top:10px">
            <button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteProject('${escape(p.name)}')">Delete</button>
          </div>
        </div>
      `).join('');
    }
    
    if (select) {
      select.innerHTML = '<option value="">Select a project...</option>' +
        data.projects.map(p => `<option value="${escape(p.name)}">${escape(p.name)}</option>`).join('');
    }
  } catch (err) {
    console.error(err);
  }
}

async function createProject() {
  showModal('New Project', `
    <div class="form-group">
      <label>Project Name</label>
      <input type="text" id="new-project-name" class="input" placeholder="My Project" maxlength="50">
    </div>
    <div class="form-group">
      <label>Description</label>
      <input type="text" id="new-project-desc" class="input" placeholder="Optional description">
    </div>
  `, `
    <button class="btn btn-secondary" onclick="hideModal()">Cancel</button>
    <button class="btn btn-primary" onclick="confirmCreateProject()">Create</button>
  `);
}

async function confirmCreateProject() {
  const name = document.getElementById('new-project-name')?.value.trim();
  const description = document.getElementById('new-project-desc')?.value.trim();
  
  if (!name) {
    notify('Name is required', 'warning');
    return;
  }
  
  try {
    await NexusApp.api('/api/projects', {
      method: 'POST',
      body: JSON.stringify({ name, description })
    });
    hideModal();
    notify('Project created', 'success');
    loadProjects();
    NexusApp.log(`Project created: ${name}`);
  } catch (err) {
    notify(err.message, 'error');
  }
}

async function deleteProject(name) {
  if (!confirm(`Delete project "${name}"? This cannot be undone.`)) return;
  
  try {
    await NexusApp.api(`/api/projects/${encodeURIComponent(name)}`, { method: 'DELETE' });
    notify('Project deleted', 'success');
    loadProjects();
  } catch (err) {
    notify(err.message, 'error');
  }
}

async function loadProjectFiles(name) {
  try {
    const data = await NexusApp.api(`/api/projects/${encodeURIComponent(name)}`);
    const container = document.getElementById('files-list');
    
    const files = data.project.files || [];
    const scripts = data.project.scripts || [];
    
    container.innerHTML = `
      <div style="margin-bottom:12px;font-size:13px;color:var(--text-secondary)">
        Project: <strong>${escape(data.project.name)}</strong>
      </div>
      <div class="resource-group">
        <h4>Scripts (${scripts.length})</h4>
        ${scripts.map(f => `<div class="file-tree-item"><span class="icon">📄</span> ${escape(f)}</div>`).join('') || '<p style="font-size:12px;color:var(--text-muted)">No scripts</p>'}
      </div>
      <div class="resource-group">
        <h4>Files (${files.length})</h4>
        ${files.map(f => `<div class="file-tree-item"><span class="icon">📄</span> ${escape(f)}</div>`).join('') || '<p style="font-size:12px;color:var(--text-muted)">No files</p>'}
      </div>
    `;
  } catch (err) {
    notify(err.message, 'error');
  }
}

function escape(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

window.confirmCreateProject = confirmCreateProject;
window.deleteProject = deleteProject;

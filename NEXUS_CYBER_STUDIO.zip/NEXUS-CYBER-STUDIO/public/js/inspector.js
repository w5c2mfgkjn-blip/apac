/**
 * URL Inspector Module
 */

let lastInspectorResult = null;

document.addEventListener('DOMContentLoaded', () => {
  const analyzeBtn = document.getElementById('inspector-analyze');
  const urlInput = document.getElementById('inspector-url');
  
  analyzeBtn?.addEventListener('click', runInspector);
  urlInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runInspector();
  });
  
  // Tabs
  document.querySelectorAll('#section-inspector .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('#section-inspector .tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderInspectorTab(tab.dataset.tab);
    });
  });
});

async function runInspector() {
  const url = document.getElementById('inspector-url').value.trim();
  if (!url) {
    notify('Please enter a URL', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api('/api/inspector/analyze', {
      method: 'POST',
      body: JSON.stringify({ url })
    });
    
    lastInspectorResult = data;
    renderInspectorMeta(data);
    renderInspectorTab('overview');
    NexusApp.log(`Inspected: ${data.url}`);
    notify('Analysis complete', 'success');
  } catch (err) {
    notify(err.message, 'error');
    document.getElementById('inspector-results').innerHTML = 
      `<div class="empty-state" style="color:var(--accent-red)">${err.message}</div>`;
  }
}

function renderInspectorMeta(data) {
  const meta = document.getElementById('inspector-meta');
  meta.classList.remove('hidden');
  meta.innerHTML = `
    <div class="meta-item"><div class="label">Status</div><div class="value">${data.status} ${data.statusText || ''}</div></div>
    <div class="meta-item"><div class="label">Size</div><div class="value">${data.sizeFormatted || data.size}</div></div>
    <div class="meta-item"><div class="label">Content-Type</div><div class="value">${data.contentType || '—'}</div></div>
    <div class="meta-item"><div class="label">Title</div><div class="value">${escapeHtml(data.title || '—')}</div></div>
  `;
}

function renderInspectorTab(tab) {
  const container = document.getElementById('inspector-results');
  if (!lastInspectorResult) {
    container.innerHTML = '<div class="empty-state">Enter a public URL and click Analyze</div>';
    return;
  }
  
  const data = lastInspectorResult;
  
  switch (tab) {
    case 'overview':
      container.innerHTML = `
        <div class="analysis-item">
          <h4>Page Info</h4>
          <p style="font-size:13px;color:var(--text-secondary)">
            <strong>URL:</strong> ${escapeHtml(data.url)}<br>
            <strong>Title:</strong> ${escapeHtml(data.title || 'N/A')}<br>
            <strong>Description:</strong> ${escapeHtml(data.description || 'N/A')}<br>
            <strong>Generator:</strong> ${escapeHtml(data.generator || 'N/A')}
          </p>
        </div>
        <div class="analysis-item">
          <h4>Resources Summary</h4>
          <ul>
            <li>Scripts: ${data.resources.scripts.total} (${data.resources.scripts.external.length} external, ${data.resources.scripts.inlineCount} inline)</li>
            <li>Stylesheets: ${data.resources.stylesheets.length}</li>
            <li>Links: ${data.resources.links.length}</li>
            <li>Images: ${data.resources.images.length}</li>
            <li>Source Maps detected: ${data.resources.sourceMaps.length}</li>
          </ul>
        </div>
      `;
      break;
      
    case 'headers':
      const headers = data.headers || {};
      container.innerHTML = `
        <div class="analysis-item">
          <h4>HTTP Headers</h4>
          <div class="code-block">${Object.entries(headers).map(([k,v]) => 
            `<span style="color:var(--accent-blue)">${escapeHtml(k)}</span>: ${escapeHtml(String(v))}`
          ).join('\n')}</div>
        </div>
      `;
      break;
      
    case 'scripts':
      container.innerHTML = `
        <div class="resource-group">
          <h4>External Scripts (${data.resources.scripts.external.length})</h4>
          ${data.resources.scripts.external.map(s => `
            <div class="resource-item">
              <span class="name" title="${escapeHtml(s.src)}">${escapeHtml(truncate(s.src, 60))}</span>
              <div class="actions">
                <button class="btn btn-sm" onclick="fetchAndShow('${escapeHtml(s.src)}')">View</button>
                <button class="btn btn-sm" onclick="window.open('${escapeHtml(s.src)}','_blank')">Open</button>
              </div>
            </div>
          `).join('') || '<p style="color:var(--text-muted);font-size:12px">No external scripts</p>'}
        </div>
        ${data.resources.sourceMaps.length ? `
          <div class="resource-group">
            <h4>Source Maps</h4>
            ${data.resources.sourceMaps.map(m => `
              <div class="resource-item">
                <span class="name">${escapeHtml(truncate(m, 60))}</span>
                <button class="btn btn-sm" onclick="document.getElementById('sourcemap-url').value='${escapeHtml(m)}';navigateTo('sourcemap')">Explore</button>
              </div>
            `).join('')}
          </div>
        ` : ''}
      `;
      break;
      
    case 'styles':
      container.innerHTML = `
        <div class="resource-group">
          <h4>Stylesheets (${data.resources.stylesheets.length})</h4>
          ${data.resources.stylesheets.map(s => `
            <div class="resource-item">
              <span class="name" title="${escapeHtml(s.href)}">${escapeHtml(truncate(s.href, 60))}</span>
              <div class="actions">
                <button class="btn btn-sm" onclick="fetchAndShow('${escapeHtml(s.href)}')">View</button>
              </div>
            </div>
          `).join('') || '<p style="color:var(--text-muted);font-size:12px">No stylesheets found</p>'}
        </div>
      `;
      break;
      
    case 'links':
      container.innerHTML = `
        <div class="resource-group">
          <h4>Links (first ${Math.min(data.resources.links.length, 100)})</h4>
          ${data.resources.links.slice(0, 50).map(l => `
            <div class="resource-item">
              <span class="name" title="${escapeHtml(l.href)}">${escapeHtml(truncate(l.href, 50))}</span>
              <span style="color:var(--text-muted);font-size:11px">${escapeHtml(truncate(l.text, 20))}</span>
            </div>
          `).join('') || '<p style="color:var(--text-muted)">No links</p>'}
        </div>
      `;
      break;
      
    case 'html':
      container.innerHTML = `
        <div class="code-toolbar">
          <span>HTML Source (${data.htmlLength} chars)</span>
          <button class="btn btn-sm" onclick="NexusApp.copyToClipboard(lastInspectorResult.html)">Copy</button>
        </div>
        <pre class="code-block">${escapeHtml(data.html || '')}</pre>
      `;
      break;
  }
}

async function fetchAndShow(url) {
  try {
    const data = await NexusApp.api('/api/inspector/fetch', {
      method: 'POST',
      body: JSON.stringify({ url })
    });
    
    showModal('Resource Content', `
      <div style="margin-bottom:8px;font-size:12px;color:var(--text-muted)">
        ${escapeHtml(data.url)} • ${data.sizeFormatted} • ${data.contentType}
      </div>
      <pre class="code-block" style="max-height:50vh">${escapeHtml(data.content.substring(0, 100000))}</pre>
    `, `<button class="btn btn-primary" onclick="NexusApp.copyToClipboard(\`${data.content.replace(/`/g, '\\`').substring(0, 50000)}\`);hideModal()">Copy</button>
       <button class="btn btn-secondary" onclick="hideModal()">Close</button>`);
  } catch (err) {
    notify(err.message, 'error');
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function truncate(str, len) {
  if (!str) return '';
  return str.length > len ? str.substring(0, len) + '…' : str;
}

window.fetchAndShow = fetchAndShow;
window.lastInspectorResult = null;
Object.defineProperty(window, 'lastInspectorResult', {
  get: () => lastInspectorResult,
  set: (v) => { lastInspectorResult = v; }
});

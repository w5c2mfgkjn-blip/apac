/**
 * Navigation Module
 */

const sections = {
  dashboard: { title: 'Dashboard', subtitle: 'Overview' },
  inspector: { title: 'URL Inspector', subtitle: 'Web Analysis' },
  sourcemap: { title: 'Source Map Explorer', subtitle: 'Original Sources' },
  scriptlab: { title: 'Script Lab', subtitle: 'Code Editor' },
  protector: { title: 'Script Protector', subtitle: 'Obfuscation & Minify' },
  analyzer: { title: 'Script Analyzer', subtitle: 'Code Analysis' },
  luau: { title: 'Luau Studio', subtitle: 'Roblox Scripts' },
  roblox: { title: 'Roblox Control Center', subtitle: 'Open Cloud' },
  security: { title: 'Security Center', subtitle: 'Vulnerability Scan' },
  files: { title: 'File Manager', subtitle: 'Workspace' },
  terminal: { title: 'Terminal', subtitle: 'Command Interface' },
  projects: { title: 'Projects', subtitle: 'Manage Projects' }
};

function navigateTo(sectionId) {
  // Update nav
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.section === sectionId);
  });
  
  // Update sections
  document.querySelectorAll('.section').forEach(sec => {
    sec.classList.toggle('active', sec.id === `section-${sectionId}`);
  });
  
  // Update title
  const info = sections[sectionId] || { title: sectionId, subtitle: '' };
  document.getElementById('section-title').textContent = info.title;
  document.getElementById('section-subtitle').textContent = info.subtitle;
  
  // Close mobile sidebar
  document.getElementById('sidebar')?.classList.remove('open');
  document.querySelector('.sidebar-overlay')?.remove();
  
  // Trigger section-specific init if needed
  window.dispatchEvent(new CustomEvent('section-change', { detail: sectionId }));
}

window.navigateTo = navigateTo;

document.addEventListener('DOMContentLoaded', () => {
  // Nav clicks
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(item.dataset.section);
    });
  });
  
  // Sidebar toggle (mobile)
  document.getElementById('sidebar-toggle')?.addEventListener('click', () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
    
    if (sidebar.classList.contains('open')) {
      const overlay = document.createElement('div');
      overlay.className = 'sidebar-overlay';
      overlay.addEventListener('click', () => {
        sidebar.classList.remove('open');
        overlay.remove();
      });
      document.body.appendChild(overlay);
    } else {
      document.querySelector('.sidebar-overlay')?.remove();
    }
  });
});

/**
 * Roblox Control Center Module
 */

document.addEventListener('DOMContentLoaded', () => {
  checkRobloxStatus();
  
  document.getElementById('roblox-fetch')?.addEventListener('click', fetchUniverse);
  document.getElementById('roblox-places')?.addEventListener('click', () => fetchEndpoint('places'));
  document.getElementById('roblox-datastores')?.addEventListener('click', () => fetchEndpoint('datastores'));
  document.getElementById('roblox-help')?.addEventListener('click', showHelp);
});

async function checkRobloxStatus() {
  try {
    const data = await fetch('/api/roblox/status').then(r => r.json());
    const el = document.getElementById('roblox-conn-status');
    if (el) {
      el.textContent = data.hasKey ? 'API Key configured' : 'API Key not set';
      el.style.color = data.hasKey ? 'var(--accent-green)' : 'var(--accent-orange)';
    }
  } catch (e) {
    const el = document.getElementById('roblox-conn-status');
    if (el) el.textContent = 'Error checking status';
  }
}

async function fetchUniverse() {
  const id = document.getElementById('roblox-universe').value.trim();
  if (!id) {
    notify('Enter a Universe ID', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api(`/api/roblox/universe/${id}`);
    document.getElementById('roblox-results').innerHTML = `
      <pre class="code-block">${JSON.stringify(data.data || data, null, 2)}</pre>
    `;
    notify('Universe data loaded', 'success');
  } catch (err) {
    document.getElementById('roblox-results').innerHTML = `
      <div class="empty-state" style="color:var(--accent-red)">${err.message}</div>
    `;
    notify(err.message, 'error');
  }
}

async function fetchEndpoint(type) {
  const id = document.getElementById('roblox-universe').value.trim();
  if (!id) {
    notify('Enter a Universe ID first', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api(`/api/roblox/universe/${id}/${type}`);
    document.getElementById('roblox-results').innerHTML = `
      <pre class="code-block">${JSON.stringify(data.data || data, null, 2)}</pre>
    `;
    notify(`${type} loaded`, 'success');
  } catch (err) {
    document.getElementById('roblox-results').innerHTML = `
      <div class="empty-state" style="color:var(--accent-red)">${err.message}</div>
    `;
    notify(err.message, 'error');
  }
}

async function showHelp() {
  try {
    const data = await fetch('/api/roblox/help').then(r => r.json());
    showModal('Roblox Open Cloud Setup', `
      <p>${data.message}</p>
      <ol style="font-size:13px;padding-left:20px;margin:12px 0">
        ${data.setup.map(s => `<li style="margin-bottom:6px">${s}</li>`).join('')}
      </ol>
      <p style="font-size:12px;color:var(--text-muted)">${data.security}</p>
      <p style="font-size:12px"><a href="${data.docs}" target="_blank" style="color:var(--accent-blue)">Official Documentation →</a></p>
    `, `<button class="btn btn-secondary" onclick="hideModal()">Close</button>`);
  } catch (e) {
    notify('Could not load help', 'error');
  }
}

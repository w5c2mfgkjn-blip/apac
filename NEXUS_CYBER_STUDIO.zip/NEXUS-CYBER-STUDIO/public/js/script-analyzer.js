/**
 * Script Analyzer Module
 */

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('analyzer-run')?.addEventListener('click', runAnalysis);
});

async function runAnalysis() {
  const code = document.getElementById('analyzer-input').value;
  if (!code.trim()) {
    notify('Paste code to analyze', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api('/api/scripts/analyze', {
      method: 'POST',
      body: JSON.stringify({ code })
    });
    
    if (data.success) {
      const a = data.analysis;
      const container = document.getElementById('analyzer-results');
      
      container.innerHTML = `
        <div class="analysis-item">
          <h4>Summary</h4>
          <p style="font-size:13px">${a.summary}</p>
          <p style="font-size:12px;color:var(--text-muted)">Detected language: ${data.language}</p>
        </div>
        
        <div class="analysis-item">
          <h4>Functions (${a.functions.length})</h4>
          <ul>${a.functions.slice(0, 50).map(f => `<li>${escape(f)}</li>`).join('') || '<li style="color:var(--text-muted)">None detected</li>'}</ul>
        </div>
        
        <div class="analysis-item">
          <h4>Variables (${a.variables.length})</h4>
          <ul>${a.variables.slice(0, 40).map(v => `<li>${escape(v)}</li>`).join('') || '<li style="color:var(--text-muted)">None detected</li>'}</ul>
        </div>
        
        ${a.dependencies?.length ? `
          <div class="analysis-item">
            <h4>Dependencies</h4>
            <ul>${a.dependencies.map(d => `<li>${escape(d)}</li>`).join('')}</ul>
          </div>
        ` : ''}
        
        ${a.potentialIssues?.length ? `
          <div class="analysis-item">
            <h4>Potential Issues</h4>
            <ul>${a.potentialIssues.map(i => `<li class="issue-item">${escape(i)}</li>`).join('')}</ul>
          </div>
        ` : '<div class="analysis-item"><h4>Issues</h4><p style="color:var(--accent-green);font-size:13px">No common issues detected</p></div>'}
      `;
      
      NexusApp.log('Code analysis completed');
      notify('Analysis complete', 'success');
    }
  } catch (err) {
    notify(err.message, 'error');
  }
}

function escape(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

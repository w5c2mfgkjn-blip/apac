/**
 * Script Lab - Multi-tab Code Editor
 */

const ScriptLab = {
  tabs: [{ id: 0, name: 'untitled.js', language: 'javascript', content: '' }],
  activeTab: 0,
  
  init() {
    const editor = document.getElementById('lab-editor');
    if (!editor) return;
    
    editor.addEventListener('input', () => this.onInput());
    editor.addEventListener('scroll', () => this.syncLines());
    editor.addEventListener('keydown', (e) => this.handleKeys(e));
    editor.addEventListener('click', () => this.updatePosition());
    editor.addEventListener('keyup', () => this.updatePosition());
    
    document.getElementById('lab-format')?.addEventListener('click', () => this.format());
    document.getElementById('lab-analyze')?.addEventListener('click', () => this.analyze());
    document.getElementById('lab-copy')?.addEventListener('click', () => {
      NexusApp.copyToClipboard(editor.value);
    });
    document.getElementById('lab-download')?.addEventListener('click', () => this.download());
    document.getElementById('lab-clear')?.addEventListener('click', () => {
      editor.value = '';
      this.onInput();
    });
    document.getElementById('lab-newtab')?.addEventListener('click', () => this.newTab());
    document.getElementById('lab-language')?.addEventListener('change', (e) => {
      this.tabs[this.activeTab].language = e.target.value;
      this.updateTabName();
    });
    
    this.renderLines();
  },
  
  onInput() {
    this.tabs[this.activeTab].content = document.getElementById('lab-editor').value;
    this.renderLines();
    this.updatePosition();
  },
  
  renderLines() {
    const editor = document.getElementById('lab-editor');
    const linesEl = document.getElementById('lab-lines');
    if (!editor || !linesEl) return;
    
    const lines = editor.value.split('\n').length;
    let html = '';
    for (let i = 1; i <= Math.max(lines, 1); i++) {
      html += `<span>${i}</span>`;
    }
    linesEl.innerHTML = html;
  },
  
  syncLines() {
    const editor = document.getElementById('lab-editor');
    const linesEl = document.getElementById('lab-lines');
    if (editor && linesEl) {
      linesEl.scrollTop = editor.scrollTop;
    }
  },
  
  updatePosition() {
    const editor = document.getElementById('lab-editor');
    const pos = document.getElementById('lab-position');
    if (!editor || !pos) return;
    
    const text = editor.value.substring(0, editor.selectionStart);
    const lines = text.split('\n');
    const line = lines.length;
    const col = lines[lines.length - 1].length + 1;
    pos.textContent = `Ln ${line}, Col ${col}`;
  },
  
  handleKeys(e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      const editor = e.target;
      const start = editor.selectionStart;
      const end = editor.selectionEnd;
      editor.value = editor.value.substring(0, start) + '  ' + editor.value.substring(end);
      editor.selectionStart = editor.selectionEnd = start + 2;
      this.onInput();
    }
  },
  
  async format() {
    const editor = document.getElementById('lab-editor');
    const lang = document.getElementById('lab-language').value;
    
    try {
      const data = await NexusApp.api('/api/scripts/format', {
        method: 'POST',
        body: JSON.stringify({ code: editor.value, language: lang })
      });
      
      if (data.success) {
        editor.value = data.code;
        this.onInput();
        document.getElementById('lab-status').textContent = 'Formatted';
        notify('Code formatted', 'success');
      } else {
        notify(data.error || 'Format failed', 'error');
      }
    } catch (err) {
      notify(err.message, 'error');
    }
  },
  
  async analyze() {
    const editor = document.getElementById('lab-editor');
    const lang = document.getElementById('lab-language').value;
    
    try {
      const data = await NexusApp.api('/api/scripts/analyze', {
        method: 'POST',
        body: JSON.stringify({ code: editor.value, language: lang })
      });
      
      if (data.success) {
        const a = data.analysis;
        showModal('Analysis Results', `
          <p><strong>Language:</strong> ${data.language}</p>
          <p>${a.summary}</p>
          <h4 style="margin-top:12px;color:var(--accent-blue)">Functions (${a.functions.length})</h4>
          <ul style="font-family:var(--font-mono);font-size:12px">${a.functions.map(f => `<li>${f}</li>`).join('') || '<li>None detected</li>'}</ul>
          ${a.potentialIssues?.length ? `
            <h4 style="margin-top:12px;color:var(--accent-orange)">Issues</h4>
            <ul style="font-size:12px">${a.potentialIssues.map(i => `<li style="color:var(--accent-orange)">${i}</li>`).join('')}</ul>
          ` : ''}
        `, `<button class="btn btn-secondary" onclick="hideModal()">Close</button>`);
      }
    } catch (err) {
      notify(err.message, 'error');
    }
  },
  
  download() {
    const editor = document.getElementById('lab-editor');
    const tab = this.tabs[this.activeTab];
    NexusApp.downloadFile(editor.value, tab.name);
  },
  
  newTab() {
    const id = this.tabs.length;
    this.tabs.push({ id, name: `untitled${id}.js`, language: 'javascript', content: '' });
    this.switchTab(id);
    this.renderTabs();
  },
  
  switchTab(id) {
    // Save current
    const editor = document.getElementById('lab-editor');
    if (editor) this.tabs[this.activeTab].content = editor.value;
    
    this.activeTab = id;
    const tab = this.tabs[id];
    if (editor) {
      editor.value = tab.content;
      document.getElementById('lab-language').value = tab.language;
    }
    this.renderTabs();
    this.renderLines();
  },
  
  renderTabs() {
    const container = document.getElementById('lab-tabs');
    if (!container) return;
    
    container.innerHTML = this.tabs.map(t => `
      <div class="editor-tab ${t.id === this.activeTab ? 'active' : ''}" data-tab="${t.id}">
        ${t.name}
      </div>
    `).join('');
    
    container.querySelectorAll('.editor-tab').forEach(el => {
      el.addEventListener('click', () => this.switchTab(parseInt(el.dataset.tab)));
    });
  },
  
  updateTabName() {
    const lang = document.getElementById('lab-language').value;
    const ext = { javascript: 'js', html: 'html', css: 'css', lua: 'lua', luau: 'luau', json: 'json', python: 'py' }[lang] || 'txt';
    this.tabs[this.activeTab].name = `untitled.${ext}`;
    this.renderTabs();
  }
};

document.addEventListener('DOMContentLoaded', () => ScriptLab.init());

// Luau Studio (shares similar editor logic)
document.addEventListener('DOMContentLoaded', () => {
  const luauEditor = document.getElementById('luau-editor');
  if (!luauEditor) return;
  
  const updateLuauLines = () => {
    const lines = luauEditor.value.split('\n').length;
    let html = '';
    for (let i = 1; i <= Math.max(lines, 1); i++) html += `<span>${i}</span>`;
    document.getElementById('luau-lines').innerHTML = html;
  };
  
  luauEditor.addEventListener('input', updateLuauLines);
  luauEditor.addEventListener('scroll', () => {
    document.getElementById('luau-lines').scrollTop = luauEditor.scrollTop;
  });
  luauEditor.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const s = luauEditor.selectionStart;
      luauEditor.value = luauEditor.value.substring(0, s) + '  ' + luauEditor.value.substring(luauEditor.selectionEnd);
      luauEditor.selectionStart = luauEditor.selectionEnd = s + 2;
      updateLuauLines();
    }
  });
  
  document.getElementById('luau-template')?.addEventListener('click', () => {
    const type = document.getElementById('luau-type').value;
    const templates = {
      Script: `-- Server Script
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- Create RemoteEvent example
local remote = Instance.new("RemoteEvent")
remote.Name = "ExampleRemote"
remote.Parent = ReplicatedStorage

remote.OnServerEvent:Connect(function(player, data)
    -- Always validate on server
    if typeof(data) ~= "table" then return end
    print(player.Name, "sent data")
end)
`,
      LocalScript: `-- LocalScript (Client)
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local player = Players.LocalPlayer
local remote = ReplicatedStorage:WaitForChild("ExampleRemote")

-- Example: send to server
remote:FireServer({ action = "test" })
`,
      ModuleScript: `-- ModuleScript
local Module = {}

function Module.doSomething(value)
    assert(typeof(value) == "number", "value must be a number")
    return value * 2
end

return Module
`
    };
    luauEditor.value = templates[type] || templates.Script;
    updateLuauLines();
    notify('Template inserted', 'success');
  });
  
  document.getElementById('luau-analyze')?.addEventListener('click', () => {
    const code = luauEditor.value;
    const remotes = [];
    const remoteMatches = code.matchAll(/(?:RemoteEvent|RemoteFunction|UnreliableRemoteEvent)[\s\S]*?Name\s*=\s*["'](\w+)["']/g);
    for (const m of remoteMatches) remotes.push(m[1]);
    
    const hasValidation = /typeof\s*\(|assert\s*\(/.test(code);
    const firesClient = /FireClient|FireAllClients|InvokeClient/.test(code);
    const firesServer = /FireServer|InvokeServer/.test(code);
    
    const panel = document.getElementById('luau-analysis');
    panel.classList.remove('hidden');
    panel.innerHTML = `
      <strong>Remote Analysis</strong><br>
      Remotes found: ${remotes.length ? remotes.join(', ') : 'None explicitly named'}<br>
      Client→Server calls: ${firesServer ? 'Yes' : 'No'}<br>
      Server→Client calls: ${firesClient ? 'Yes' : 'No'}<br>
      Validation present: ${hasValidation ? '✓ Yes' : '⚠ Consider adding type checks'}
    `;
  });
  
  document.getElementById('luau-copy')?.addEventListener('click', () => {
    NexusApp.copyToClipboard(luauEditor.value);
  });
  
  document.getElementById('luau-download')?.addEventListener('click', () => {
    const type = document.getElementById('luau-type').value;
    NexusApp.downloadFile(luauEditor.value, `${type}.luau`);
  });
  
  updateLuauLines();
});

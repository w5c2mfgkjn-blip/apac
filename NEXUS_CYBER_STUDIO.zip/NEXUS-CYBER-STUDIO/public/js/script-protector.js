/**
 * Script Protector Module
 */

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('protector-obfuscate')?.addEventListener('click', () => process('obfuscate'));
  document.getElementById('protector-minify')?.addEventListener('click', () => process('minify'));
  document.getElementById('protector-compact')?.addEventListener('click', () => process('compact'));
  document.getElementById('protector-copy')?.addEventListener('click', () => {
    const out = document.getElementById('protector-output').value;
    if (out) NexusApp.copyToClipboard(out);
  });
  document.getElementById('protector-download')?.addEventListener('click', () => {
    const out = document.getElementById('protector-output').value;
    if (out) NexusApp.downloadFile(out, 'protected.js');
  });
});

async function process(action) {
  const input = document.getElementById('protector-input').value;
  if (!input.trim()) {
    notify('Paste some JavaScript code first', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api(`/api/scripts/${action}`, {
      method: 'POST',
      body: JSON.stringify({ code: input })
    });
    
    if (data.success) {
      document.getElementById('protector-output').value = data.code;
      
      const stats = document.getElementById('protector-stats');
      if (data.originalSize && (data.obfuscatedSize || data.minifiedSize || data.compactedSize)) {
        const newSize = data.obfuscatedSize || data.minifiedSize || data.compactedSize;
        const ratio = ((1 - newSize / data.originalSize) * 100).toFixed(1);
        stats.textContent = `${formatBytes(data.originalSize)} → ${formatBytes(newSize)} (${ratio > 0 ? '-' : '+'}${Math.abs(ratio)}%)`;
      }
      
      if (data.warning) {
        notify(data.warning, 'warning', 6000);
      } else {
        notify(`${action} complete`, 'success');
      }
      
      NexusApp.log(`Script ${action} applied`);
    } else {
      notify(data.error || 'Processing failed', 'error');
    }
  } catch (err) {
    notify(err.message, 'error');
  }
}

function formatBytes(b) {
  if (b < 1024) return b + ' B';
  return (b / 1024).toFixed(1) + ' KB';
}

/**
 * Security Center Module
 */

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('security-scan')?.addEventListener('click', runSecurityScan);
});

async function runSecurityScan() {
  const code = document.getElementById('security-input').value;
  if (!code.trim()) {
    notify('Paste code to scan', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api('/api/security/scan', {
      method: 'POST',
      body: JSON.stringify({ code })
    });
    
    if (data.success) {
      const scoreClass = data.score >= 80 ? 'score-high' : data.score >= 50 ? 'score-mid' : 'score-low';
      
      document.getElementById('security-results').innerHTML = `
        <div class="score-badge ${scoreClass}">Security Score: ${data.score}/100</div>
        
        ${data.warnings.length ? `
          <div class="analysis-item">
            <h4>Warnings (${data.warnings.length})</h4>
            <ul>${data.warnings.map(w => `<li class="issue-item">${escape(w)}</li>`).join('')}</ul>
          </div>
        ` : '<p style="color:var(--accent-green);font-size:13px;margin-bottom:12px">✓ No major issues detected</p>'}
        
        <div class="analysis-item">
          <h4>Functions Found</h4>
          <ul>${data.functions.slice(0, 20).map(f => `<li>${escape(f)}</li>`).join('') || '<li>None</li>'}</ul>
        </div>
        
        <div class="analysis-item">
          <h4>Recommendations</h4>
          <ul>${data.recommendations.map(r => `<li style="color:var(--text-secondary)">${r}</li>`).join('')}</ul>
        </div>
      `;
      
      NexusApp.log(`Security scan completed (score: ${data.score})`);
      notify(`Scan complete — Score: ${data.score}/100`, data.score >= 70 ? 'success' : 'warning');
    }
  } catch (err) {
    notify(err.message, 'error');
  }
}

function escape(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

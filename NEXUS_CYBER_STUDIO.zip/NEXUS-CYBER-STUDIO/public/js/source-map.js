/**
 * Source Map Explorer Module
 */

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('sourcemap-load')?.addEventListener('click', loadSourceMapUrl);
  document.getElementById('sourcemap-parse')?.addEventListener('click', parseSourceMapContent);
  document.getElementById('sourcemap-copy')?.addEventListener('click', () => {
    const code = document.getElementById('sourcemap-source').textContent;
    NexusApp.copyToClipboard(code);
  });
});

async function loadSourceMapUrl() {
  const url = document.getElementById('sourcemap-url').value.trim();
  if (!url) {
    notify('Enter a source map URL', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api('/api/scripts/source-map', {
      method: 'POST',
      body: JSON.stringify({ url })
    });
    renderSourceMap(data);
    notify(`Loaded ${data.sourcesCount} sources`, 'success');
  } catch (err) {
    notify(err.message, 'error');
  }
}

async function parseSourceMapContent() {
  const content = document.getElementById('sourcemap-content').value.trim();
  if (!content) {
    notify('Paste source map JSON', 'warning');
    return;
  }
  
  try {
    const data = await NexusApp.api('/api/scripts/source-map', {
      method: 'POST',
      body: JSON.stringify({ content })
    });
    renderSourceMap(data);
    notify(`Parsed ${data.sourcesCount} sources`, 'success');
  } catch (err) {
    notify(err.message, 'error');
  }
}

function renderSourceMap(data) {
  const list = document.getElementById('sourcemap-files');
  const codeView = document.getElementById('sourcemap-code');
  
  if (!data.files || data.files.length === 0) {
    list.innerHTML = '<div class="empty-state">No sources found in map</div>';
    codeView.classList.add('hidden');
    return;
  }
  
  list.innerHTML = data.files.map((f, i) => `
    <div class="file-item" data-index="${i}">
      <span class="name">${escapeHtml(f.name)}</span>
      <span style="font-size:11px;color:${f.hasContent ? 'var(--accent-green)' : 'var(--text-muted)'}">
        ${f.hasContent ? 'has content' : 'no content'}
      </span>
    </div>
  `).join('');
  
  list.querySelectorAll('.file-item').forEach(item => {
    item.addEventListener('click', () => {
      const idx = parseInt(item.dataset.index);
      const file = data.files[idx];
      document.getElementById('sourcemap-filename').textContent = file.name;
      document.getElementById('sourcemap-source').textContent = file.content || '// No source content available in this map';
      codeView.classList.remove('hidden');
    });
  });
}

function escapeHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

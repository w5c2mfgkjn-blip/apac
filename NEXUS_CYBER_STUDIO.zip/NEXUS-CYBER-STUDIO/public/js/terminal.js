/**
 * Terminal Module
 * Safe project operations only
 */

const Terminal = {
  history: [],
  historyIndex: -1,
  
  commands: {
    help: () => {
      return `Available commands:
  help          - Show this help
  clear         - Clear terminal
  status        - System status
  projects      - List projects
  health        - Backend health check
  version       - Show version
  echo <text>   - Print text
  date          - Current date/time`;
    },
    
    clear: () => {
      document.getElementById('terminal-output').innerHTML = '';
      return null;
    },
    
    status: async () => {
      try {
        const res = await fetch('/api/health');
        const data = await res.json();
        return `Backend: ${data.status}\nService: ${data.service}\nVersion: ${data.version}\nTime: ${data.timestamp}`;
      } catch (e) {
        return 'Backend unreachable';
      }
    },
    
    health: async () => {
      return Terminal.commands.status();
    },
    
    projects: async () => {
      try {
        const data = await NexusApp.api('/api/projects');
        if (!data.projects.length) return 'No projects found.';
        return data.projects.map(p => `• ${p.name} — ${p.description || 'no description'}`).join('\n');
      } catch (e) {
        return 'Error: ' + e.message;
      }
    },
    
    version: () => `NEXUS CYBER STUDIO v${NexusApp.version}`,
    
    date: () => new Date().toString(),
    
    echo: (args) => args.join(' ') || ''
  },
  
  init() {
    const input = document.getElementById('terminal-input');
    if (!input) return;
    
    input.addEventListener('keydown', async (e) => {
      if (e.key === 'Enter') {
        const cmd = input.value.trim();
        if (!cmd) return;
        
        this.print(cmd, 'cmd');
        this.history.push(cmd);
        this.historyIndex = this.history.length;
        input.value = '';
        
        await this.execute(cmd);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (this.historyIndex > 0) {
          this.historyIndex--;
          input.value = this.history[this.historyIndex];
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (this.historyIndex < this.history.length - 1) {
          this.historyIndex++;
          input.value = this.history[this.historyIndex];
        } else {
          this.historyIndex = this.history.length;
          input.value = '';
        }
      }
    });
    
    document.getElementById('terminal-clear')?.addEventListener('click', () => {
      document.getElementById('terminal-output').innerHTML = '';
    });
  },
  
  print(text, type = 'output') {
    const out = document.getElementById('terminal-output');
    if (!out) return;
    
    const lines = String(text).split('\n');
    lines.forEach(line => {
      const el = document.createElement('div');
      el.className = `term-line ${type}`;
      if (type === 'cmd') {
        el.textContent = 'nexus> ' + line;
      } else {
        el.textContent = line;
      }
      out.appendChild(el);
    });
    out.scrollTop = out.scrollHeight;
  },
  
  async execute(input) {
    const parts = input.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);
    
    if (this.commands[cmd]) {
      try {
        const result = await this.commands[cmd](args);
        if (result !== null && result !== undefined) {
          this.print(result, 'output');
        }
      } catch (e) {
        this.print('Error: ' + e.message, 'error');
      }
    } else {
      this.print(`Unknown command: ${cmd}. Type "help" for available commands.`, 'error');
    }
  }
};

document.addEventListener('DOMContentLoaded', () => Terminal.init());

/**
 * NEXUS CYBER STUDIO - Main Server
 * Professional cybersecurity & development platform
 */

require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const fs = require('fs-extra');

// Routes
const inspectorRoutes = require('./backend/routes/inspector');
const scriptsRoutes = require('./backend/routes/scripts');
const robloxRoutes = require('./backend/routes/roblox');
const securityRoutes = require('./backend/routes/security');

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure workspace exists
const workspaceDir = path.join(__dirname, 'workspace', 'projects');
fs.ensureDirSync(workspaceDir);

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://*"],
      frameSrc: ["'none'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));

app.use(cors({
  origin: true,
  credentials: true
}));

app.use(morgan('dev'));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  message: { error: 'Too many requests, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false
});
app.use('/api/', limiter);

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/inspector', inspectorRoutes);
app.use('/api/scripts', scriptsRoutes);
app.use('/api/roblox', robloxRoutes);
app.use('/api/security', securityRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'NEXUS CYBER STUDIO',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Project management endpoints
app.get('/api/projects', async (req, res) => {
  try {
    const projects = await fs.readdir(workspaceDir);
    const projectList = [];
    
    for (const name of projects) {
      const projectPath = path.join(workspaceDir, name);
      const stat = await fs.stat(projectPath);
      if (stat.isDirectory()) {
        let meta = { name, description: '', created: stat.birthtime, modified: stat.mtime };
        const metaPath = path.join(projectPath, 'project.json');
        if (await fs.pathExists(metaPath)) {
          const data = await fs.readJson(metaPath);
          meta = { ...meta, ...data };
        }
        projectList.push(meta);
      }
    }
    
    res.json({ success: true, projects: projectList });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/projects', async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name || !/^[a-zA-Z0-9_\-\s]{1,50}$/.test(name)) {
      return res.status(400).json({ success: false, error: 'Invalid project name' });
    }
    
    const safeName = name.trim().replace(/\s+/g, '_');
    const projectPath = path.join(workspaceDir, safeName);
    
    if (await fs.pathExists(projectPath)) {
      return res.status(409).json({ success: false, error: 'Project already exists' });
    }
    
    await fs.ensureDir(projectPath);
    await fs.ensureDir(path.join(projectPath, 'scripts'));
    await fs.ensureDir(path.join(projectPath, 'files'));
    
    const meta = {
      name: safeName,
      description: description || '',
      created: new Date().toISOString(),
      modified: new Date().toISOString()
    };
    
    await fs.writeJson(path.join(projectPath, 'project.json'), meta, { spaces: 2 });
    
    res.json({ success: true, project: meta });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/projects/:name', async (req, res) => {
  try {
    const projectPath = path.join(workspaceDir, req.params.name);
    if (!await fs.pathExists(projectPath)) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }
    
    const meta = await fs.readJson(path.join(projectPath, 'project.json'));
    const files = await fs.readdir(path.join(projectPath, 'files')).catch(() => []);
    const scripts = await fs.readdir(path.join(projectPath, 'scripts')).catch(() => []);
    
    res.json({ success: true, project: { ...meta, files, scripts } });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/projects/:name', async (req, res) => {
  try {
    const projectPath = path.join(workspaceDir, req.params.name);
    if (!await fs.pathExists(projectPath)) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }
    await fs.remove(projectPath);
    res.json({ success: true, message: 'Project deleted' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Fallback to index.html for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handler
app.use((err, req, res, next) => {
  console.error('[ERROR]', err.message);
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
  });
});

app.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════════════════════════╗
  ║                                                       ║
  ║   ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗         ║
  ║   ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝         ║
  ║   ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗         ║
  ║   ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║         ║
  ║   ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║         ║
  ║   ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝         ║
  ║                                                       ║
  ║   CYBER STUDIO v1.0.0                                 ║
  ║   Running on http://localhost:${PORT}                    ║
  ║                                                       ║
  ╚═══════════════════════════════════════════════════════╝
  `);
});
